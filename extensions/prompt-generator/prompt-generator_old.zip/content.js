function saveSelection() {
  const text = String(window.getSelection ? window.getSelection().toString() : "").trim();
  if (!text) return;

  chrome.storage.local.set({
    promptGeneratorSelection: {
      text: text.slice(0, 5000),
      pageTitle: document.title || "",
      pageUrl: location.href,
      capturedAt: new Date().toISOString()
    }
  });
}

document.addEventListener("mouseup", saveSelection);
document.addEventListener("keyup", (event) => {
  if (!event.shiftKey && !event.ctrlKey && !event.metaKey) return;
  saveSelection();
});
