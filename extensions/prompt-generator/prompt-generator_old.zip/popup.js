const HISTORY_LIMIT = 8;

const elements = {
  selectedText: document.getElementById("selected-text"),
  selectionMeta: document.getElementById("selection-meta"),
  brief: document.getElementById("brief"),
  useCase: document.getElementById("use-case"),
  tone: document.getElementById("tone"),
  outputFormat: document.getElementById("output-format"),
  audience: document.getElementById("audience"),
  constraints: document.getElementById("constraints"),
  includeChecklist: document.getElementById("include-checklist"),
  result: document.getElementById("result"),
  status: document.getElementById("status"),
  history: document.getElementById("history"),
  generate: document.getElementById("generate"),
  copyResult: document.getElementById("copy-result"),
  refreshSelection: document.getElementById("refresh-selection"),
  clearHistory: document.getElementById("clear-history")
};

init();

async function init() {
  await hydrateSelection();
  await renderHistory();

  elements.generate.addEventListener("click", handleGenerate);
  elements.copyResult.addEventListener("click", handleCopy);
  elements.refreshSelection.addEventListener("click", hydrateSelection);
  elements.clearHistory.addEventListener("click", clearHistory);
}

async function hydrateSelection() {
  const { promptGeneratorSelection } = await chrome.storage.local.get("promptGeneratorSelection");
  const selection = promptGeneratorSelection || {};

  elements.selectedText.value = selection.text || "";
  elements.selectionMeta.textContent = selection.text
    ? `Captured from ${selection.pageTitle || "this page"}`
    : "No saved page selection yet.";
}

function handleGenerate() {
  const selectedText = clean(elements.selectedText.value);
  const brief = clean(elements.brief.value);
  const constraints = clean(elements.constraints.value);
  const useCase = elements.useCase.value;
  const tone = elements.tone.value;
  const outputFormat = elements.outputFormat.value;
  const audience = elements.audience.value;
  const includeChecklist = elements.includeChecklist.checked;

  const prompt = buildPrompt({
    selectedText,
    brief,
    constraints,
    useCase,
    tone,
    outputFormat,
    audience,
    includeChecklist
  });

  elements.result.value = prompt;
  elements.status.textContent = "Prompt generated. Review and copy it.";
  saveHistory({
    createdAt: new Date().toISOString(),
    title: brief || "Untitled prompt",
    prompt
  }).then(renderHistory);
}

async function handleCopy() {
  if (!elements.result.value.trim()) {
    elements.status.textContent = "Generate a prompt first.";
    return;
  }

  await navigator.clipboard.writeText(elements.result.value);
  elements.status.textContent = "Prompt copied to clipboard.";
}

async function saveHistory(entry) {
  const { promptGeneratorHistory } = await chrome.storage.local.get("promptGeneratorHistory");
  const history = Array.isArray(promptGeneratorHistory) ? promptGeneratorHistory : [];
  const nextHistory = [entry, ...history].slice(0, HISTORY_LIMIT);
  await chrome.storage.local.set({ promptGeneratorHistory: nextHistory });
}

async function renderHistory() {
  const { promptGeneratorHistory } = await chrome.storage.local.get("promptGeneratorHistory");
  const history = Array.isArray(promptGeneratorHistory) ? promptGeneratorHistory : [];

  if (!history.length) {
    elements.history.innerHTML = '<p class="empty">No recent prompts yet.</p>';
    return;
  }

  elements.history.innerHTML = history.map((entry, index) => `
    <article class="history-card">
      <strong>${escapeHtml(entry.title || "Untitled prompt")}</strong>
      <p class="meta">${escapeHtml(trim(entry.prompt, 96))}</p>
      <button type="button" data-history-index="${index}">Load</button>
    </article>
  `).join("");

  elements.history.querySelectorAll("[data-history-index]").forEach((button) => {
    button.addEventListener("click", async () => {
      const target = history[Number(button.dataset.historyIndex)];
      elements.result.value = target.prompt || "";
      elements.status.textContent = "Loaded a recent prompt.";
    });
  });
}

async function clearHistory() {
  await chrome.storage.local.set({ promptGeneratorHistory: [] });
  elements.result.value = "";
  elements.status.textContent = "Recent history cleared.";
  await renderHistory();
}

function buildPrompt({
  selectedText,
  brief,
  constraints,
  useCase,
  tone,
  outputFormat,
  audience,
  includeChecklist
}) {
  const useCaseLabel = labelFor(useCase, {
    general: "general work",
    writing: "writing",
    coding: "coding",
    research: "research",
    translation: "translation",
    marketing: "marketing"
  });
  const toneLabel = labelFor(tone, {
    direct: "direct and pragmatic",
    friendly: "friendly and clear",
    executive: "executive summary style",
    technical: "technical and precise",
    creative: "creative but usable"
  });
  const formatLabel = labelFor(outputFormat, {
    bullets: "bullet list",
    markdown: "markdown sections",
    json: "JSON",
    table: "table",
    "step-by-step": "step-by-step plan"
  });
  const audienceLabel = labelFor(audience, {
    general: "a general user",
    manager: "a manager",
    developer: "a developer",
    designer: "a designer",
    customer: "a customer"
  });

  const sections = [
    "You are an expert assistant for " + useCaseLabel + ".",
    "",
    "[Goal]",
    brief || "Help with the selected material and produce a practical result.",
    "",
    "[Audience]",
    `Write for ${audienceLabel}.`,
    "",
    "[Tone]",
    toneLabel + ".",
    "",
    "[Output Format]",
    `Return the answer as ${formatLabel}.`,
    "",
    "[Context]",
    selectedText || "No page selection was provided.",
    "",
    "[Constraints]",
    constraints || "Stay accurate, avoid filler, and ask a clarifying question only if critical."
  ];

  if (includeChecklist) {
    sections.push(
      "",
      "[Self-Check]",
      "Before finalizing, verify that the answer is specific, actionable, and aligned with the requested format."
    );
  }

  return sections.join("\n");
}

function clean(value) {
  return String(value || "").trim();
}

function trim(value, maxLength) {
  const text = String(value || "").trim();
  return text.length > maxLength ? text.slice(0, maxLength - 1) + "…" : text;
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function labelFor(value, map) {
  return map[value] || value;
}
