const CLEAR_SELECTION_MENU_ID = "prompt-generator-clear-selection";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: CLEAR_SELECTION_MENU_ID,
    title: "Clear Prompt Generator selection",
    contexts: ["action"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId !== CLEAR_SELECTION_MENU_ID) return;

  chrome.storage.local.set({
    promptGeneratorSelection: {
      text: "",
      pageTitle: "",
      pageUrl: "",
      capturedAt: ""
    }
  });
});
